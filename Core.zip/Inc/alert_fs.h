/*
 * alert_fs.h
 *
 *  Created on: Jul 12, 2024
 *      Author: ihg78
 */

#ifndef INC_ALERT_FS_H_
#define INC_ALERT_FS_H_
#include "g_var.h"
#include "main.h"
#include "lcd_menu.h"

void start_Boozer();
void end_Boozer();

void check_Alarm();

#endif /* INC_ALERT_FS_H_ */
