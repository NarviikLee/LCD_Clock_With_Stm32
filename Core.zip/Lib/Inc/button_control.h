/*
 * button_control.h
 *
 *  Created on: Jul 17, 2024
 *      Author: ihg78
 */

#ifndef LIB_INC_BUTTON_CONTROL_H_
#define LIB_INC_BUTTON_CONTROL_H_
#include "g_var.h"


void main_Check();
void sel_Pos_control();

void sub_Menu();
void timer_Completed();
void judge_timer();
#endif /* LIB_INC_BUTTON_CONTROL_H_ */
