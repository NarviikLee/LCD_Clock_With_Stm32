/*
 * alert_fs.c
 *
 *  Created on: Jul 12, 2024
 *      Author: ihg78
 */
#include "alert_fs.h"
#include "timer_mode.h"
#include "ssd1306.h"

void start_Boozer(int mode){
	toggleScreen();
	if(mode ==1){
		setTMode(0);
	}
	else if (mode == 2){
		setAlarmState(0);
	}
	setTimerCompleted(1);
}

void end_Boozer(int mode){
	alert_mode = 0;
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);
	if(mode == 1){
		setTimerCompleted(0);
	}else if (mode == 2){
		setAlarmCompleted(0);
	}
}
void check_Alarm(){
	if(alarm_value[2] == clock_value[2] && alarm_value[1] == clock_value[1] && alarm_value[0] == clock_value[0]){
		start_Boozer(2);
		setAlarmCompleted(1);
	}
}
